#!/bin/bash


step=1 #间隔的秒数，不能大于60

for (( i = 0; i < 60; i=(i+step) ))
do
	ps -ef | grep Change_network.sh | grep -v grep &> /dev/null
	if [ $? = 0 ];
	then
		echo " [ `date` ] " > /home/NETWORK/check.log
	else
        systemctl start change_network
	fi
	sleep $step
done

exit 0
