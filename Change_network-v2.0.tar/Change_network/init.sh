#!/bin/bash

#create workdir
mkdir -p /home/NETWORK/

#copy config and bash file to workdir
scp ./Change_network.sh /home/NETWORK/
scp ./check_change_network.sh /home/NETWORK/
scp ./change_network.service /usr/lib/systemd/system/

#add permission
chmod 777 /home/NETWORK/Change_network.sh
chmod 777 /home/NETWORK/check_change_network.sh
chmod a+x /etc/rc.d/rc.local
chattr +i /home/NETWORK/*

#add service boot up
echo "* * * * * /bin/sh /home/NETWORK/check_change_network.sh" >> /var/spool/cron/root
echo "/bin/sh /home/NETWORK/check_change_network.sh" >> /etc/rc.d/rc.local
systemctl daemon-reload
systemctl enable change_network
systemctl start change_network

mv ./init.sh .init.sh
