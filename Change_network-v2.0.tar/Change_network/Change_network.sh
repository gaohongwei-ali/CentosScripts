#!/bin/bash

right_status='yes'


#check eth0 status
check_eth0_status(){
	eth0_status=`ethtool eth0 | grep 'Link detected' | awk -F ':' '{print $2}' | grep -o -E 'yes|no'`
}

#check active nic
check_active_status(){
	active_status=`cat /proc/net/bonding/bond0| grep Active | grep -o -E 'eth0|eth1'`
}

#change eth0 to eth1
change_active_status(){
	ifenslave -c bond0 eth1
}
while true
do
	check_eth0_status
	if [[ ${eth0_status} = yes ]];
	then
	    sleep 0.01
    else
		check_active_status
		if [[ ${active_status} = eth0 ]];
		then
			change_active_status
		else
			sleep 0.01
		fi
    fi
	sleep 0.5
done

